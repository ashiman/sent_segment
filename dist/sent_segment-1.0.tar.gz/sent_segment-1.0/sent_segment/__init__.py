from utils.spacy_utils import SpacyUtils
name = "sent_segment"
spacy_utils = SpacyUtils()