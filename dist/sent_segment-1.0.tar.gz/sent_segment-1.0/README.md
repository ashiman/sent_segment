# Example Package
This is an API for sentence segmentation.